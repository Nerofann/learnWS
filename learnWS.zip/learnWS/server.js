const http    = require('http');
const server  = require('ws');
const ws      = new server.Server({noServer:true});
let clients   = new Set();

function onSocketConnect(ws, request) {
    let search = request.url.split('?')[1];
    let params = JSON.parse('{"' + decodeURI(search)
                        .replace(/"/g, '\\"').replace(/&/g, '","')
                        .replace(/=/g, '":"') + '"}'
    );
                        
    clients.add({
        c_srv: ws,
        c_id: params.client_id
    });
  
    ws.on('message', function(message) {
        console.log("receive: %s", message);
        let c_req = JSON.parse(message); 

        for(let client of clients) {
            if(client.c_id == c_req.to) {
                //Handle penerima
                console.log("receive message from client: %s", c_req.from);
                client.c_srv.send(JSON.stringify(c_req));
            }

            if(client.c_id == c_req.from && c_req.message != '') {
                //Handle pengirim
                console.log("send message to client: %s", c_req.to);
                client.c_srv.send(JSON.stringify(c_req));
            }
        }
    })
}

http.createServer((req, res) => {
    if(req.headers.upgrade.toLowerCase() == 'websocket') {
        console.log(req.url);
        ws.handleUpgrade(req, req.socket, Buffer.alloc(0), onSocketConnect);
    }
}).listen(8080);